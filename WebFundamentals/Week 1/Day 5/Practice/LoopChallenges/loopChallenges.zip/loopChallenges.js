for(i=1;i<=20;i++){
    if(i%2===1){
        console.log(i);
    }
}

for(i=100;i>=0;i--){
    if(i%3===0){
        console.log(i);
    }
}
var n=4;
for(i=5;i>=0;i--){
    console.log(n);
    n-=1.5;
}
var sum=0;
for(i=1;i<=100;i++){
    sum+=i;
}
console.log(sum);

result=1;

for(i=1;i<=12;i++){
    result*=i;
}
console.log(result);